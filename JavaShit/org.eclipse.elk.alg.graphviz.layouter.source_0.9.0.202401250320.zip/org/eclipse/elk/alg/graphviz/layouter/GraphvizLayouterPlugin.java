/*******************************************************************************
 * Copyright (c) 2008, 2015 Kiel University and others.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *******************************************************************************/
package org.eclipse.elk.alg.graphviz.layouter;

import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle.
 * 
 * @author msp
 */
public class GraphvizLayouterPlugin extends Plugin {

    /** the plug-in ID. */
    public static final String PLUGIN_ID = "org.eclipse.elk.alg.graphviz.layouter";

    /** the shared instance. */
    private static GraphvizLayouterPlugin plugin;

    /**
     * The constructor.
     */
    public GraphvizLayouterPlugin() {
    }

    @Override
    public void start(final BundleContext context) throws Exception {
        super.start(context);
        plugin = this;
    }

    @Override
    public void stop(final BundleContext context) throws Exception {
        plugin = null;
        super.stop(context);
    }

    /**
     * Returns the shared instance.
     * 
     * @return the shared instance
     */
    public static GraphvizLayouterPlugin getDefault() {
        return plugin;
    }

}
